({
    doinit : function(component, event, helper) {
        helper.getProductlistFn(component);
    }
})